package com.pronet.company;

/**
 * Created by parin on 3/29/15.
 */
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.sun.javafx.beans.IDProperty;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import java.util.List;


@DynamoDBTable(tableName="CompanyDetails")
public class CompanyDetails {

    private String ID;
    private String name;
    private String logo;
    private String url;
    private String overview;

    public CompanyDetails(){}

    public CompanyDetails(@JsonProperty String id, @JsonProperty String name, @JsonProperty String logo, @JsonProperty String url, @JsonProperty String overview) {
        this.name = name;
        this.logo = logo;
        this.url=url;
        this.ID=id;
        this.overview=overview;
    }

    @DynamoDBHashKey(attributeName="ID")
    public String getID() {
        return ID;
    }

    @DynamoDBAttribute(attributeName="name")
    public String getName() {
        return name;
    }

    @DynamoDBAttribute(attributeName="logo")
    public String getLogo() {
        return logo;
    }

    @DynamoDBAttribute(attributeName="url")
    public String getUrl() {
        return url;
    }

    @DynamoDBAttribute(attributeName="overview")
    public String getOverview() {
        return overview;
    }
}
